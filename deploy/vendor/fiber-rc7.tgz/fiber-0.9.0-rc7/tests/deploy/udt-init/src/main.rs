use ckb_chain_spec::ChainSpec;
use ckb_resource::Resource;
use ckb_sdk::{
    transaction::{
        builder::{sudt::SudtTransactionBuilder, CkbTransactionBuilder},
        handler::{sighash::Secp256k1Blake160SighashAllScriptHandler, sudt::SudtHandler},
        input::InputIterator,
        signer::{SignContexts, TransactionSigner},
        TransactionBuilderConfiguration,
    },
    Address, CkbRpcClient, NetworkInfo, ScriptId,
};
use ckb_types::{
    core::BlockView,
    packed::CellOutput,
    prelude::{Entity, Unpack},
};
use ckb_types::{
    core::{DepType, ScriptHashType},
    packed::{OutPoint, Script},
    prelude::Pack,
    H256,
};
use ckb_types::{packed::CellDep, prelude::Builder};
use rand::Rng;
use serde::{Deserialize, Serialize};
use std::{collections::HashSet, path::Path};
use std::{fs, net::TcpListener};

use std::{error::Error as StdErr, str::FromStr};

const UDT_KINDS: [&str; 2] = ["SIMPLE_UDT", "XUDT"];

fn get_udt_info(udt_kind: &str) -> (H256, H256, usize) {
    let genesis_block = build_gensis_block();
    let genesis_tx = genesis_block
        .transaction(0)
        .expect("genesis block transaction #0 should exist");

    let index = if udt_kind == "SIMPLE_UDT" { 8 } else { 9 };
    let output_data = genesis_tx.outputs_data().get(index).unwrap().raw_data();
    (
        CellOutput::calc_data_hash(&output_data).unpack(),
        genesis_tx.hash().unpack(),
        index,
    )
}

fn gen_dev_udt_handler(udt_kind: &str) -> SudtHandler {
    let (data_hash, genesis_tx, index) = get_udt_info(udt_kind);
    let script_id = ScriptId::new(data_hash, ScriptHashType::Data2);

    let udt_cell_dep = CellDep::new_builder()
        .out_point(
            OutPoint::new_builder()
                .tx_hash(genesis_tx.pack())
                .index(index)
                .build(),
        )
        .dep_type(DepType::Code)
        .build();

    ckb_sdk::transaction::handler::sudt::SudtHandler::new_with_customize(
        vec![udt_cell_dep],
        script_id,
    )
}

fn gen_dev_sighash_handler() -> Secp256k1Blake160SighashAllScriptHandler {
    let genesis_block = build_gensis_block();
    let secp256k1_dep_group_tx_hash = genesis_block
        .transaction(1)
        .expect("genesis block transaction #1 should exist")
        .hash();
    let secp256k1_dep_group_out_point = OutPoint::new_builder()
        .tx_hash(secp256k1_dep_group_tx_hash)
        .index(0u32)
        .build();
    let cell_dep = CellDep::new_builder()
        .out_point(secp256k1_dep_group_out_point)
        .dep_type(DepType::DepGroup)
        .build();

    Secp256k1Blake160SighashAllScriptHandler::new_with_customize(vec![cell_dep])
}

fn generate_configuration(
    udt_kind: &str,
) -> Result<(NetworkInfo, TransactionBuilderConfiguration), Box<dyn StdErr>> {
    let network_info = NetworkInfo::devnet();
    let mut configuration =
        TransactionBuilderConfiguration::new_devnet().expect("new devnet configuration");

    configuration.register_script_handler(Box::new(gen_dev_sighash_handler()));
    configuration.register_script_handler(Box::new(gen_dev_udt_handler(udt_kind)));
    return Ok((network_info, configuration));
}

fn init_or_send_udt(
    udt_kind: &str,
    issuer_address: &str,
    sender_info: &(String, H256),
    receiver_address: Option<&str>,
    sudt_amount: u128,
    apply: bool,
) -> Result<(), Box<dyn StdErr>> {
    let (network_info, configuration) = generate_configuration(udt_kind)?;

    let issuer = Address::from_str(issuer_address)?;
    let sender = Address::from_str(&sender_info.0)?;
    let receiver = if let Some(addr) = receiver_address {
        Address::from_str(addr)?
    } else {
        sender.clone()
    };

    let iterator = InputIterator::new_with_address(&[sender], &network_info);
    let owner_mode = receiver_address.is_none();
    let mut builder = SudtTransactionBuilder::new(configuration, iterator, &issuer, owner_mode)?;
    builder.set_sudt_type_script(generate_udt_type_script(udt_kind, issuer_address));
    builder.add_output(&receiver, sudt_amount);

    let mut tx_with_groups = builder.build(&Default::default())?;

    let private_keys = vec![sender_info.1.clone()];

    TransactionSigner::new(&network_info).sign_transaction(
        &mut tx_with_groups,
        &SignContexts::new_sighash_h256(private_keys)?,
    )?;

    let json_tx = ckb_jsonrpc_types::TransactionView::from(tx_with_groups.get_tx_view().clone());
    if apply {
        let tx_hash = CkbRpcClient::new(network_info.url.as_str())
            .send_transaction(json_tx.inner, None)
            .expect("send transaction");
        println!(">>> tx {} sent! <<<", tx_hash);
    } else {
        let result = CkbRpcClient::new(network_info.url.as_str())
            .test_tx_pool_accept(json_tx.inner, None)
            .expect("accept transaction");
        println!(">>> check tx result: {:?}  <<<", result);
    }

    Ok(())
}

fn generate_blocks(num: u64) -> Result<(), Box<dyn StdErr>> {
    let network_info = NetworkInfo::devnet();
    let rpc_client = CkbRpcClient::new(network_info.url.as_str());
    for _i in 0..num {
        rpc_client.generate_block()?;
        // sleep 200ms
        std::thread::sleep(std::time::Duration::from_millis(200));
    }
    Ok(())
}

fn generate_udt_type_script(udt_kind: &str, address: &str) -> ckb_types::packed::Script {
    let address = Address::from_str(address).expect("parse address");
    let sudt_owner_lock_script: Script = (&address).into();
    let (code_hash, _, _) = get_udt_info(udt_kind);
    Script::new_builder()
        .code_hash(code_hash.pack())
        .hash_type(ScriptHashType::Data2)
        .args(sudt_owner_lock_script.calc_script_hash().as_bytes().pack())
        .build()
}

fn get_nodes_info(node: &str) -> (String, H256) {
    let nodes_dir = std::env::var("NODES_DIR").expect("env var");
    let node_dir = format!("{}/{}", nodes_dir, node);
    let wallet = std::fs::read_to_string(format!("{}/ckb/wallet", node_dir)).expect("read failed");
    let key = std::fs::read_to_string(format!("{}/ckb/plain_key", node_dir)).expect("read failed");
    (wallet, H256::from_str(key.trim()).expect("parse hex"))
}

#[derive(Serialize, Deserialize, Clone, Debug)]
struct UdtScript {
    code_hash: H256,
    hash_type: String,
    /// args may be used in pattern matching
    args: String,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
struct UdtDep {
    cell_dep: Option<UdtCellDep>,
    type_id: Option<ckb_jsonrpc_types::Script>,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
struct UdtCellDep {
    out_point: ckb_jsonrpc_types::OutPoint,
    dep_type: String,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
struct UdtInfo {
    name: String,
    script: UdtScript,
    auto_accept_amount: Option<u128>,
    cell_deps: Vec<UdtDep>,
}

fn is_port_available(port: u16) -> bool {
    match TcpListener::bind(("127.0.0.1", port)) {
        Ok(listener) => {
            drop(listener); // Close the listener
            true
        }
        Err(_) => false,
    }
}

fn generate_ports(num_ports: usize) -> Vec<u16> {
    let mut ports = HashSet::new();
    let mut rng = rand::rng();

    while ports.len() < num_ports {
        // avoid https://en.wikipedia.org/wiki/Ephemeral_port
        let port: u16 = rng.random_range(1024..32768);
        if is_port_available(port) {
            ports.insert(port);
        }
    }

    ports.into_iter().collect()
}

fn create_node_config(
    base_data: &serde_yaml::Value,
    udt_infos: &[UdtInfo],
    node_index: usize,
    fiber_port: u16,
    rpc_port: u16,
    node3_rpc_port: Option<u16>,
) -> serde_yaml::Value {
    let mut config = base_data.clone();

    config["fiber"]["listening_addr"] =
        serde_yaml::Value::String(format!("/ip4/0.0.0.0/tcp/{}", fiber_port));
    config["fiber"]["announced_addrs"] =
        serde_yaml::Value::Sequence(vec![serde_yaml::Value::String(format!(
            "/ip4/127.0.0.1/tcp/{}",
            fiber_port
        ))]);
    config["fiber"]["announced_node_name"] =
        serde_yaml::Value::String(format!("fiber-{}", node_index));
    config["rpc"]["listening_addr"] = serde_yaml::Value::String(format!("127.0.0.1:{}", rpc_port));
    config["ckb"]["udt_whitelist"] = serde_yaml::to_value(udt_infos).unwrap();

    // Node 3 acts as a CCH node (in-process mode)
    if node_index == 3 {
        config["services"]
            .as_sequence_mut()
            .unwrap()
            .push(serde_yaml::Value::String("cch".to_string()));
    }

    // Node 4 (cch) is a standalone CCH service connecting to node 3 via RPC
    if node_index == 4 {
        // Remove fiber and ckb sections — CCH-only node doesn't run these
        config.as_mapping_mut().unwrap().remove("fiber");
        config.as_mapping_mut().unwrap().remove("ckb");

        // Remove ignore_startup_failure from CCH config — must succeed for CCH-only node
        if let Some(cch) = config.get_mut("cch") {
            cch.as_mapping_mut()
                .unwrap()
                .remove("ignore_startup_failure");
            // Point to node 3's RPC
            let target_rpc_port = node3_rpc_port.unwrap_or(21713 + 3);
            cch["fiber_rpc_url"] =
                serde_yaml::Value::String(format!("http://127.0.0.1:{}", target_rpc_port));

            // Standalone CCH needs the full wrapped BTC type script because
            // the contracts context is not available without fiber/ckb services.
            let wrapped_btc_args = cch["wrapped_btc_type_script_args"]
                .as_str()
                .expect("wrapped_btc_type_script_args must be set")
                .to_string();
            let (code_hash, _, _) = get_udt_info("SIMPLE_UDT");
            let script_json = format!(
                r#"{{"code_hash":"0x{:x}","hash_type":"data2","args":"{}"}}"#,
                code_hash, wrapped_btc_args
            );
            cch["wrapped_btc_type_script"] = serde_yaml::Value::String(script_json);
        }

        // Only enable cch module in RPC
        config["rpc"]["enabled_modules"] =
            serde_yaml::Value::Sequence(vec![serde_yaml::Value::String("cch".to_string())]);

        // Services: only rpc and cch
        config["services"] = serde_yaml::Value::Sequence(vec![
            serde_yaml::Value::String("rpc".to_string()),
            serde_yaml::Value::String("cch".to_string()),
        ]);
    }

    config
}

fn write_node_config(
    nodes_dir: &Path,
    config_dir: &str,
    header: &str,
    config_data: &serde_yaml::Value,
    dev_config: &Path,
) {
    let yaml_content = header.to_string() + &serde_yaml::to_string(config_data).unwrap();
    let config_path = nodes_dir.join(config_dir).join("config.yml");
    std::fs::write(config_path, yaml_content).expect("write config failed");

    let node_dev_config = nodes_dir.join(config_dir).join("dev.toml");
    // CCH-only node doesn't need dev.toml (no fiber/ckb sections)
    if config_dir != "cch" {
        fs::copy(dev_config, node_dev_config).expect("copy dev.toml failed");
    }
}

fn generate_nodes_config() {
    let node_dir_env = std::env::var("NODES_DIR").expect("env var");
    let nodes_dir = Path::new(&node_dir_env);
    let yaml_file_path = nodes_dir.join("deployer/config.yml");
    let content = std::fs::read_to_string(yaml_file_path).expect("read failed");
    let data: serde_yaml::Value = serde_yaml::from_str(&content).expect("Unable to parse YAML");
    let mut udt_infos = vec![];
    for udt in UDT_KINDS {
        let (code_hash, genesis_tx, index) = get_udt_info(udt);
        let udt_info = UdtInfo {
            name: udt.to_string(),
            auto_accept_amount: Some(1000),
            script: UdtScript {
                code_hash: code_hash,
                hash_type: "Data2".to_string(),
                args: "0x.*".to_string(),
            },
            cell_deps: vec![UdtDep {
                cell_dep: Some(UdtCellDep {
                    dep_type: "code".to_string(),
                    out_point: ckb_jsonrpc_types::OutPoint {
                        tx_hash: genesis_tx,
                        index: (index as u32).into(),
                    },
                }),
                type_id: None,
            }],
        };
        udt_infos.push(udt_info);
    }
    let header = format!(
        "{}\n{}\n\n",
        "# this is generated from nodes/deployer/config.yml, any changes will not be checked in",
        "# you can edit nodes/deployer/config.yml and run `REMOVE_OLD_STATE=y ./tests/nodes/start.sh TESTCASE` to regenerate"
    );
    let config_dirs = ["bootnode", "1", "2", "3", "cch"];
    let on_github_action = std::env::var("ON_GITHUB_ACTION").is_ok();
    let gen_ports = if on_github_action {
        Some(generate_ports(8).into_iter())
    } else {
        None
    };
    let mut gen_ports_iter = gen_ports;
    let mut ports_map: Vec<(u16, u16)> = Vec::new();
    let dev_config = nodes_dir.join("deployer/dev.toml");

    let mut node3_rpc_port: Option<u16> = None;

    for (i, &config_dir) in config_dirs.iter().enumerate() {
        let default_ports = (8343 + i as u16, 21713 + i as u16);
        let (fiber_port, rpc_port) = match (&mut gen_ports_iter, i) {
            (Some(iter), i) if i != 0 => (iter.next().unwrap(), iter.next().unwrap()),
            _ => default_ports,
        };
        ports_map.extend([(8343 + i as u16, fiber_port), (21713 + i as u16, rpc_port)]);

        // Remember node 3's actual RPC port for the CCH-only node
        if i == 3 {
            node3_rpc_port = Some(rpc_port);
        }

        let config_data =
            create_node_config(&data, &udt_infos, i, fiber_port, rpc_port, node3_rpc_port);
        write_node_config(&nodes_dir, config_dir, &header, &config_data, &dev_config);
    }

    if on_github_action {
        if let Err(e) = update_bruno_configs(&nodes_dir, &ports_map) {
            eprintln!("Warning: Failed to update Bruno configs: {}", e);
        }
    }

    // Write ports for nodes that always start (1, 2, 3) so wait.sh can verify they're ready.
    // Bootnode (first 2 entries) and CCH-only node (last 2 entries) start conditionally,
    // so their ports are excluded.
    let content = ports_map
        .iter()
        .skip(2)
        .take(6)
        .map(|(_, port)| port.to_string())
        .collect::<Vec<_>>()
        .join("\n")
        + "\n";

    let port_file_path = nodes_dir.join(".ports");
    std::fs::write(port_file_path, content).expect("write ports list");
}

fn update_bruno_configs(nodes_dir: &Path, ports_map: &[(u16, u16)]) -> Result<(), Box<dyn StdErr>> {
    let bruno_dir = nodes_dir.join("../bruno/environments/");

    for config_entry in std::fs::read_dir(bruno_dir)? {
        let config_path = config_entry?.path();
        let mut content = std::fs::read_to_string(&config_path)?;

        // Apply all port replacements
        for (default_port, actual_port) in ports_map {
            content = content.replace(&default_port.to_string(), &actual_port.to_string());
        }

        std::fs::write(&config_path, content)?;
    }

    Ok(())
}

fn init_udt_accounts() -> Result<(), Box<dyn StdErr>> {
    let udt_owner = get_nodes_info("deployer");
    for udt in UDT_KINDS {
        init_or_send_udt(
            udt,
            &udt_owner.0,
            &udt_owner,
            None,
            0xfffffffffffffffffffffffffffffff,
            true,
        )
        .expect("init udt");
        generate_blocks(8).expect("ok");
        std::thread::sleep(std::time::Duration::from_millis(1000));
        for i in 0..3 {
            let wallet = get_nodes_info(&(i + 1).to_string());
            init_or_send_udt(
                udt,
                &udt_owner.0,
                &udt_owner,
                Some(&wallet.0),
                0xffffffffffffffffffffffffffffff,
                true,
            )?;
            generate_blocks(8).expect("ok");
        }

        let script = generate_udt_type_script(udt, &udt_owner.0);
        println!("initialized udt_type_script: {} ...", script);
    }
    Ok(())
}

fn build_gensis_block() -> BlockView {
    let node_dir_env = std::env::var("NODES_DIR").expect("env var");
    let nodes_dir = Path::new(&node_dir_env);
    let dev_toml = nodes_dir.join("deployer/dev.toml");
    let chain_spec =
        ChainSpec::load_from(&Resource::file_system(dev_toml)).expect("load chain spec");
    let genesis_block = chain_spec.build_genesis().expect("build genesis block");
    genesis_block
}

fn main() -> Result<(), Box<dyn StdErr>> {
    generate_nodes_config();
    init_udt_accounts()?;
    Ok(())
}
