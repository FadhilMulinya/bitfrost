pub mod mig_20250724;
// following new migration should be added here ...
// pub(crate) mod sample;
pub mod mig_20251219;
pub mod mig_20260203_channel_index;
pub mod mig_20260203_trampoline;
pub mod mig_20260204_pubkey_channel_index;
pub mod mig_20260301_network_state_pubkey;
pub mod mig_20260302_channel_open_record;
pub mod mig_20260302_channel_replay_fields;
