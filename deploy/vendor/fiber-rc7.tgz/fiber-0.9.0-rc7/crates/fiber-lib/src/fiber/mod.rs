pub mod channel;
pub mod config;
pub mod gossip;
pub mod graph;
pub mod history;
pub mod network;
pub mod payment;
#[cfg(all(feature = "pprof", not(target_arch = "wasm32")))]
pub mod profiling;
pub mod types;

mod fee;
pub(crate) mod gossip_policy;
mod in_flight_ckb_tx_actor;
mod key;
#[cfg(not(target_arch = "wasm32"))]
pub(crate) mod onion_service;
mod path;
#[cfg(not(target_arch = "wasm32"))]
pub(crate) mod proxy;
mod settle_tlc_set_command;

pub use config::FiberConfig;
pub use fiber_types::*;
pub use in_flight_ckb_tx_actor::{
    InFlightCkbTxActor, InFlightCkbTxActorArguments, InFlightCkbTxActorMessage, InFlightCkbTxKind,
};
pub use key::KeyPair;
pub use network::{
    start_network, NetworkActor, NetworkActorCommand, NetworkActorEvent, NetworkActorMessage,
    NetworkServiceEvent,
};
pub use settle_tlc_set_command::SettleTlcSetCommand;

pub(crate) const ASSUME_NETWORK_ACTOR_ALIVE: &str = "network actor must be alive";

#[cfg(test)]
pub mod tests;
