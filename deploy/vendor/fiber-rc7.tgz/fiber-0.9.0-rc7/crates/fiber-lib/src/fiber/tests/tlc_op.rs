use crate::fiber::{
    AppliedFlags, CommitmentNumbers, Hash256, InboundTlcStatus, OutboundTlcStatus,
    PaymentOnionPacket, RemoveTlcFulfill, RemoveTlcReason, TLCId, TlcInfo, TlcStatus,
    NO_SHARED_SECRET,
};
use crate::gen_rand_sha256_hash;
use crate::now_timestamp_as_millis_u64;
use ckb_hash::new_blake2b;
use ckb_types::packed::Byte32;
use fiber_types::HashAlgorithm;
use fiber_types::TlcState;

use ractor::{Actor, ActorProcessingErr, ActorRef};
use std::collections::HashMap;

fn sign_tlcs<'a>(tlcs: impl Iterator<Item = &'a TlcInfo>) -> Hash256 {
    // serialize active_tls to ge a hash
    let mut keyparts = tlcs
        .map(|tlc| (tlc.amount, tlc.payment_hash))
        .collect::<Vec<_>>();

    keyparts.sort_by(|a, b| {
        let a: Byte32 = a.1.into();
        let b: Byte32 = b.1.into();
        a.cmp(&b)
    });

    eprintln!("keyparts: {:?}", keyparts);
    let serialized = serde_json::to_string(&keyparts).expect("Failed to serialize tls");

    // Hash the serialized data using SHA-256
    let mut hasher = new_blake2b();
    hasher.update(serialized.to_string().as_bytes());
    let mut result = [0u8; 32];
    hasher.finalize(&mut result);

    result.into()
}

pub struct TlcActorState {
    pub tlc_state: TlcState,
    pub pubkey: String,
}

impl TlcActorState {
    pub fn get_peer(&self) -> String {
        if self.pubkey == "peer_a" {
            "peer_b".to_string()
        } else {
            "peer_a".to_string()
        }
    }
}

pub struct NetworkActorState {
    network: ActorRef<NetworkActorMessage>,
    pub peers: HashMap<String, ActorRef<TlcActorMessage>>,
}

impl NetworkActorState {
    pub async fn add_peer(&mut self, pubkey: String) {
        let network = self.network.clone();
        let actor = Actor::spawn_linked(
            Some(pubkey.clone()),
            TlcActor::new(network.clone()),
            pubkey.clone(),
            network.clone().get_cell(),
        )
        .await
        .expect("Failed to start tlc actor")
        .0;
        self.peers.insert(pubkey.clone(), actor);
        eprintln!("add_peer: {:?} added successfully ...", pubkey);
    }
}

pub struct TlcActor {
    network: ActorRef<NetworkActorMessage>,
}

impl TlcActor {
    pub fn new(network: ActorRef<NetworkActorMessage>) -> Self {
        Self { network }
    }
}

#[derive(Debug, Clone)]
pub struct AddTlcCommand {
    pub amount: u128,
    pub payment_hash: Hash256,
    /// The attempt id associate with the tlc
    pub attempt_id: Option<u64>,
    pub expiry: u64,
    pub hash_algorithm: HashAlgorithm,
    pub onion_packet: Option<PaymentOnionPacket>,
    pub shared_secret: [u8; 32],
    #[allow(dead_code)]
    pub previous_tlc: Option<(Hash256, u64)>,
}

pub struct NetworkActor {}

#[derive(Debug)]
pub enum TlcActorMessage {
    Debug,
    CommandAddTlc(AddTlcCommand),
    CommandRemoveTlc(u64),
    PeerAddTlc(TlcInfo),
    PeerRemoveTlc(u64),
    PeerCommitmentSigned(Hash256),
    PeerRevokeAndAck(Hash256),
    //PeerRemoveTlc,
}

#[derive(Debug)]
pub enum NetworkActorMessage {
    RegisterPeer(String),
    AddTlc(String, AddTlcCommand),
    RemoveTlc(String, u64),
    PeerMsg(String, TlcActorMessage),
}

#[async_trait::async_trait]
impl Actor for NetworkActor {
    type Msg = NetworkActorMessage;
    type State = NetworkActorState;
    type Arguments = ();

    async fn handle(
        &self,
        _myself: ActorRef<Self::Msg>,
        message: Self::Msg,
        state: &mut Self::State,
    ) -> Result<(), ActorProcessingErr> {
        match message {
            NetworkActorMessage::RegisterPeer(pubkey) => {
                state.add_peer(pubkey).await;
            }
            NetworkActorMessage::AddTlc(pubkey, add_tlc) => {
                eprintln!("NetworkActorMessage::AddTlc");
                if let Some(actor) = state.peers.get(&pubkey) {
                    actor
                        .send_message(TlcActorMessage::CommandAddTlc(add_tlc))
                        .expect("send ok");
                }
            }
            NetworkActorMessage::RemoveTlc(pubkey, tlc_id) => {
                if let Some(actor) = state.peers.get(&pubkey) {
                    actor
                        .send_message(TlcActorMessage::CommandRemoveTlc(tlc_id))
                        .expect("send ok");
                }
            }
            NetworkActorMessage::PeerMsg(pubkey, peer_msg) => {
                if let Some(actor) = state.peers.get(&pubkey) {
                    eprintln!("NetworkActorMessage::PeerMsg: {:?}", peer_msg);
                    actor.send_message(peer_msg).expect("send ok");
                }
            }
        }
        Ok(())
    }

    async fn pre_start(
        &self,
        myself: ActorRef<Self::Msg>,
        _args: Self::Arguments,
    ) -> Result<Self::State, ActorProcessingErr> {
        eprintln!("NetworkActor pre_start");
        Ok(NetworkActorState {
            peers: Default::default(),
            network: myself.clone(),
        })
    }
}

#[async_trait::async_trait]
impl Actor for TlcActor {
    type Msg = TlcActorMessage;
    type State = TlcActorState;
    type Arguments = String;

    async fn handle(
        &self,
        _myself: ActorRef<Self::Msg>,
        message: Self::Msg,
        state: &mut Self::State,
    ) -> Result<(), ActorProcessingErr> {
        match message {
            TlcActorMessage::Debug => {
                eprintln!("Peer {} Debug", state.pubkey);
                for tlc in state.tlc_state.offered_tlcs.tlcs.iter() {
                    eprintln!("offered_tlc: {:?}", tlc.log());
                }
                for tlc in state.tlc_state.received_tlcs.tlcs.iter() {
                    eprintln!("received_tlc: {:?}", tlc.log());
                }
            }
            TlcActorMessage::CommandAddTlc(command) => {
                eprintln!(
                    "Peer {} TlcActorMessage::Command_AddTlc: {:?}",
                    state.pubkey, command
                );
                let next_offer_id = state.tlc_state.get_next_offering();
                let add_tlc = TlcInfo {
                    tlc_id: TLCId::Offered(next_offer_id),
                    amount: command.amount,
                    payment_hash: command.payment_hash,
                    attempt_id: command.attempt_id,
                    expiry: command.expiry,
                    hash_algorithm: command.hash_algorithm,
                    created_at: CommitmentNumbers::default(),
                    removed_reason: None,
                    onion_packet: command.onion_packet,
                    shared_secret: command.shared_secret,
                    is_trampoline_hop: false,
                    forwarding_tlc: None,
                    status: TlcStatus::Outbound(OutboundTlcStatus::LocalAnnounced),
                    removed_confirmed_at: None,
                    applied_flags: AppliedFlags::empty(),
                    total_amount: None,
                    payment_secret: None,
                };
                state.tlc_state.add_offered_tlc(add_tlc.clone());
                state.tlc_state.increment_offering();
                let peer = state.get_peer();
                self.network
                    .send_message(NetworkActorMessage::PeerMsg(
                        peer.clone(),
                        TlcActorMessage::PeerAddTlc(add_tlc),
                    ))
                    .expect("send ok");

                // send commitment signed
                let tlcs = state.tlc_state.commitment_signed_tlcs(false);
                let hash = sign_tlcs(tlcs);
                eprintln!("got hash: {:?}", hash);
                self.network
                    .send_message(NetworkActorMessage::PeerMsg(
                        peer,
                        TlcActorMessage::PeerCommitmentSigned(hash),
                    ))
                    .expect("send ok");
            }
            TlcActorMessage::CommandRemoveTlc(tlc_id) => {
                eprintln!("Peer {} process remove tlc ....", state.pubkey);
                state.tlc_state.set_received_tlc_removed(
                    tlc_id,
                    RemoveTlcReason::RemoveTlcFulfill(RemoveTlcFulfill {
                        payment_preimage: Default::default(),
                    }),
                );
                let peer = state.get_peer();
                self.network
                    .send_message(NetworkActorMessage::PeerMsg(
                        peer.clone(),
                        TlcActorMessage::PeerRemoveTlc(tlc_id),
                    ))
                    .expect("send ok");

                // send commitment signed
                let tlcs = state.tlc_state.commitment_signed_tlcs(false);
                let hash = sign_tlcs(tlcs);
                eprintln!("got hash: {:?}", hash);
                self.network
                    .send_message(NetworkActorMessage::PeerMsg(
                        peer,
                        TlcActorMessage::PeerCommitmentSigned(hash),
                    ))
                    .expect("send ok");
            }
            TlcActorMessage::PeerAddTlc(add_tlc) => {
                eprintln!(
                    "Peer {} process peer add_tlc .... with tlc_id: {:?}",
                    state.pubkey, add_tlc.tlc_id
                );
                let mut tlc = add_tlc.clone();
                tlc.flip_mut();
                tlc.status = TlcStatus::Inbound(InboundTlcStatus::RemoteAnnounced);
                state.tlc_state.add_received_tlc(tlc);
                eprintln!("add peer tlc successfully: {:?}", add_tlc);
            }
            TlcActorMessage::PeerRemoveTlc(tlc_id) => {
                eprintln!(
                    "Peer {} process peer remove tlc .... with tlc_id: {}",
                    state.pubkey, tlc_id
                );
                dbg!("set offered tlc removed", &tlc_id);
                state.tlc_state.set_offered_tlc_removed(
                    tlc_id,
                    RemoveTlcReason::RemoveTlcFulfill(RemoveTlcFulfill {
                        payment_preimage: Default::default(),
                    }),
                );
            }
            TlcActorMessage::PeerCommitmentSigned(peer_hash) => {
                eprintln!(
                    "\nPeer {} processed peer commitment_signed ....",
                    state.pubkey
                );
                let tlcs = state.tlc_state.commitment_signed_tlcs(true);
                let hash = sign_tlcs(tlcs);
                assert_eq!(hash, peer_hash);

                let peer = state.get_peer();

                state.tlc_state.update_for_commitment_signed();

                eprintln!("sending peer revoke and ack ....");
                let tlcs = state.tlc_state.commitment_signed_tlcs(false);
                let hash = sign_tlcs(tlcs);
                self.network
                    .send_message(NetworkActorMessage::PeerMsg(
                        peer.clone(),
                        TlcActorMessage::PeerRevokeAndAck(hash),
                    ))
                    .expect("send ok");

                // send commitment signed from our side if necessary
                if state.tlc_state.need_another_commitment_signed() {
                    eprintln!("sending another commitment signed ....");
                    let tlcs = state.tlc_state.commitment_signed_tlcs(false);
                    let hash = sign_tlcs(tlcs);
                    self.network
                        .send_message(NetworkActorMessage::PeerMsg(
                            peer,
                            TlcActorMessage::PeerCommitmentSigned(hash),
                        ))
                        .expect("send ok");
                }
            }
            TlcActorMessage::PeerRevokeAndAck(peer_hash) => {
                eprintln!("Peer {} processed peer revoke and ack ....", state.pubkey);
                let tlcs = state.tlc_state.commitment_signed_tlcs(true);
                let hash = sign_tlcs(tlcs);
                assert_eq!(hash, peer_hash);

                state
                    .tlc_state
                    .update_for_revoke_and_ack(CommitmentNumbers::default());
            }
        }
        Ok(())
    }

    async fn pre_start(
        &self,
        _myself: ActorRef<Self::Msg>,
        args: Self::Arguments,
    ) -> Result<Self::State, ActorProcessingErr> {
        let pubkey = args;
        {
            Ok(TlcActorState {
                tlc_state: Default::default(),
                pubkey,
            })
        }
    }
}

#[cfg_attr(not(target_arch = "wasm32"), tokio::test)]
#[cfg_attr(target_arch = "wasm32", wasm_bindgen_test::wasm_bindgen_test)]
async fn test_tlc_actor() {
    let (network_actor, _handle) = Actor::spawn(None, NetworkActor {}, ())
        .await
        .expect("Failed to start tlc actor");
    network_actor
        .send_message(NetworkActorMessage::RegisterPeer("peer_a".to_string()))
        .unwrap();
    network_actor
        .send_message(NetworkActorMessage::RegisterPeer("peer_b".to_string()))
        .unwrap();

    network_actor
        .send_message(NetworkActorMessage::AddTlc(
            "peer_a".to_string(),
            AddTlcCommand {
                amount: 10000,
                payment_hash: gen_rand_sha256_hash(),
                attempt_id: None,
                expiry: now_timestamp_as_millis_u64() + 1000,
                hash_algorithm: HashAlgorithm::Sha256,
                onion_packet: None,
                shared_secret: NO_SHARED_SECRET,
                previous_tlc: None,
            },
        ))
        .unwrap();

    ractor::concurrency::sleep(tokio::time::Duration::from_millis(1000)).await;

    network_actor
        .send_message(NetworkActorMessage::AddTlc(
            "peer_a".to_string(),
            AddTlcCommand {
                amount: 20000,
                payment_hash: gen_rand_sha256_hash(),
                attempt_id: None,
                expiry: now_timestamp_as_millis_u64() + 1000,
                hash_algorithm: HashAlgorithm::Sha256,
                onion_packet: None,
                shared_secret: NO_SHARED_SECRET,
                previous_tlc: None,
            },
        ))
        .unwrap();

    ractor::concurrency::sleep(tokio::time::Duration::from_millis(1000)).await;

    network_actor
        .send_message(NetworkActorMessage::AddTlc(
            "peer_b".to_string(),
            AddTlcCommand {
                amount: 30000,
                payment_hash: gen_rand_sha256_hash(),
                attempt_id: None,
                expiry: now_timestamp_as_millis_u64() + 1000,
                hash_algorithm: HashAlgorithm::Sha256,
                onion_packet: None,
                shared_secret: NO_SHARED_SECRET,
                previous_tlc: None,
            },
        ))
        .unwrap();

    ractor::concurrency::sleep(tokio::time::Duration::from_millis(1000)).await;

    network_actor
        .send_message(NetworkActorMessage::AddTlc(
            "peer_b".to_string(),
            AddTlcCommand {
                amount: 50000,
                payment_hash: gen_rand_sha256_hash(),
                attempt_id: None,
                expiry: now_timestamp_as_millis_u64() + 1000,
                hash_algorithm: HashAlgorithm::Sha256,
                onion_packet: None,
                shared_secret: NO_SHARED_SECRET,
                previous_tlc: None,
            },
        ))
        .unwrap();

    ractor::concurrency::sleep(tokio::time::Duration::from_millis(1000)).await;
    // remove tlc from peer_b
    network_actor
        .send_message(NetworkActorMessage::RemoveTlc("peer_b".to_string(), 0))
        .unwrap();

    ractor::concurrency::sleep(tokio::time::Duration::from_millis(1000)).await;
    network_actor
        .send_message(NetworkActorMessage::PeerMsg(
            "peer_a".to_string(),
            TlcActorMessage::Debug,
        ))
        .unwrap();

    ractor::concurrency::sleep(tokio::time::Duration::from_millis(100)).await;
    network_actor
        .send_message(NetworkActorMessage::PeerMsg(
            "peer_b".to_string(),
            TlcActorMessage::Debug,
        ))
        .unwrap();

    ractor::concurrency::sleep(tokio::time::Duration::from_millis(2000)).await;
}

#[cfg_attr(target_arch = "wasm32", wasm_bindgen_test::wasm_bindgen_test)]
#[cfg_attr(not(target_arch = "wasm32"), test)]
fn test_tlc_state_v2() {
    use fiber_types::TlcState;
    let mut tlc_state = TlcState::default();
    let mut add_tlc1 = TlcInfo {
        amount: 10000,
        status: TlcStatus::Outbound(OutboundTlcStatus::LocalAnnounced),
        payment_hash: gen_rand_sha256_hash(),
        attempt_id: None,
        expiry: now_timestamp_as_millis_u64() + 1000,
        hash_algorithm: HashAlgorithm::Sha256,
        onion_packet: None,
        shared_secret: NO_SHARED_SECRET,
        is_trampoline_hop: false,
        tlc_id: TLCId::Offered(0),
        created_at: CommitmentNumbers::default(),
        removed_reason: None,
        forwarding_tlc: None,
        removed_confirmed_at: None,
        applied_flags: AppliedFlags::empty(),
        total_amount: None,
        payment_secret: None,
    };
    let mut add_tlc2 = TlcInfo {
        amount: 20000,
        status: TlcStatus::Outbound(OutboundTlcStatus::LocalAnnounced),
        payment_hash: gen_rand_sha256_hash(),
        attempt_id: None,
        expiry: now_timestamp_as_millis_u64() + 2000,
        hash_algorithm: HashAlgorithm::Sha256,
        onion_packet: None,
        shared_secret: NO_SHARED_SECRET,
        is_trampoline_hop: false,
        tlc_id: TLCId::Offered(1),
        created_at: CommitmentNumbers::default(),
        removed_reason: None,
        forwarding_tlc: None,
        removed_confirmed_at: None,
        applied_flags: AppliedFlags::empty(),
        total_amount: None,
        payment_secret: None,
    };
    tlc_state.add_offered_tlc(add_tlc1.clone());
    tlc_state.add_offered_tlc(add_tlc2.clone());

    let mut tlc_state_2 = TlcState::default();
    add_tlc1.flip_mut();
    add_tlc2.flip_mut();
    add_tlc1.status = TlcStatus::Inbound(InboundTlcStatus::RemoteAnnounced);
    add_tlc2.status = TlcStatus::Inbound(InboundTlcStatus::RemoteAnnounced);
    tlc_state_2.add_received_tlc(add_tlc1);
    tlc_state_2.add_received_tlc(add_tlc2);

    let hash1 = sign_tlcs(tlc_state.commitment_signed_tlcs(true));
    eprintln!("hash1: {:?}", hash1);

    let hash2 = sign_tlcs(tlc_state_2.commitment_signed_tlcs(false));
    eprintln!("hash2: {:?}", hash2);
    assert_eq!(hash1, hash2);
}
