use ckb_hash::blake2b_256;
use ckb_types::core::TransactionView;
use ckb_types::packed::CellOutput;
use ckb_types::packed::OutPoint;
use ckb_types::prelude::{Builder, Entity, Unpack};
use secp256k1::{Keypair, PublicKey, SecretKey, XOnlyPublicKey, SECP256K1};

use crate::ckb::contracts::{get_cell_deps_by_contracts, get_script_by_contract, Contract};
use crate::fiber::network::get_chain_hash;
use crate::fiber::types::new_channel_update_unsigned;
use crate::fiber::{
    ChannelAnnouncement, ChannelUpdate, ChannelUpdateChannelFlags, ChannelUpdateMessageFlags,
    EcdsaSignature, FeatureVector, NodeAnnouncement, Privkey, Pubkey,
};
use crate::now_timestamp_as_millis_u64;
use fiber_types::protocol::AnnouncedNodeName;

pub fn gen_rand_fiber_public_key() -> Pubkey {
    gen_rand_secp256k1_public_key().into()
}

pub fn gen_rand_fiber_private_key() -> Privkey {
    gen_rand_secp256k1_private_key().into()
}

pub fn gen_deterministic_fiber_private_key() -> Privkey {
    gen_deterministic_secp256k1_private_key().into()
}

pub fn gen_rand_secp256k1_private_key() -> SecretKey {
    gen_rand_secp256k1_keypair_tuple().0
}

pub fn gen_deterministic_secp256k1_private_key() -> SecretKey {
    gen_deterministic_secp256k1_keypair_tuple().0
}

pub fn gen_rand_secp256k1_public_key() -> PublicKey {
    gen_rand_secp256k1_keypair_tuple().1
}

pub fn gen_rand_secp256k1_keypair() -> Keypair {
    Keypair::new(SECP256K1, &mut rand::thread_rng())
}

pub fn gen_rand_secp256k1_keypair_tuple() -> (SecretKey, PublicKey) {
    let key_pair = gen_rand_secp256k1_keypair();
    (
        SecretKey::from_keypair(&key_pair),
        PublicKey::from_keypair(&key_pair),
    )
}

pub fn gen_deterministic_secp256k1_keypair() -> Keypair {
    Keypair::from_secret_key(SECP256K1, &SecretKey::from_slice(&[42u8; 32]).unwrap())
}

pub fn gen_deterministic_secp256k1_keypair_tuple() -> (SecretKey, PublicKey) {
    let key_pair = gen_deterministic_secp256k1_keypair();
    (
        SecretKey::from_keypair(&key_pair),
        PublicKey::from_keypair(&key_pair),
    )
}

pub fn gen_rand_channel_outpoint() -> OutPoint {
    let rand_slice = (0..36).map(|_| rand::random::<u8>()).collect::<Vec<u8>>();
    OutPoint::from_slice(&rand_slice).unwrap()
}

pub fn gen_rand_node_announcement() -> (Privkey, NodeAnnouncement) {
    let sk = gen_rand_fiber_private_key();
    let node_announcement = gen_node_announcement_from_privkey(&sk);
    (sk, node_announcement)
}

pub fn gen_node_announcement_from_privkey(sk: &Privkey) -> NodeAnnouncement {
    NodeAnnouncement::new_signed(
        AnnouncedNodeName::from_string("node1").expect("valid name"),
        FeatureVector::default(),
        vec![],
        sk,
        get_chain_hash(),
        now_timestamp_as_millis_u64(),
        0,
        Default::default(),
        env!("CARGO_PKG_VERSION").to_string(),
    )
}

pub async fn create_funding_tx(x_only: &XOnlyPublicKey) -> TransactionView {
    let capacity = 100u64;
    let commitment_lock_script_args = [&blake2b_256(x_only.serialize())[0..20]].concat();

    TransactionView::new_advanced_builder()
        .cell_deps(
            get_cell_deps_by_contracts(vec![Contract::Secp256k1Lock])
                .await
                .expect("get cell deps"),
        )
        .output(
            CellOutput::new_builder()
                .capacity(capacity)
                .lock(get_script_by_contract(
                    Contract::CommitmentLock,
                    commitment_lock_script_args.as_slice(),
                ))
                .build(),
        )
        .output_data(ckb_types::packed::Bytes::default())
        .build()
}

pub struct ChannelTestContext {
    pub funding_tx_sk: Privkey,
    pub node1_sk: Privkey,
    pub node2_sk: Privkey,
    pub funding_tx: TransactionView,
    pub channel_announcement: ChannelAnnouncement,
}

impl ChannelTestContext {
    pub async fn gen() -> ChannelTestContext {
        let funding_tx_sk = gen_rand_fiber_private_key();
        let node1_sk = gen_rand_fiber_private_key();
        let node2_sk = gen_rand_fiber_private_key();
        let xonly = funding_tx_sk.x_only_pub_key();
        let funding_tx = create_funding_tx(&xonly).await;
        let outpoint = funding_tx.output_pts_iter().next().unwrap();
        let capacity: u64 = funding_tx.output(0).unwrap().capacity().unpack();
        let mut channel_announcement = ChannelAnnouncement::new_unsigned(
            &node1_sk.pubkey(),
            &node2_sk.pubkey(),
            outpoint.clone(),
            get_chain_hash(),
            &xonly,
            capacity as u128,
            None,
        );
        let message = channel_announcement.message_to_sign();

        channel_announcement.ckb_signature = Some(funding_tx_sk.sign_schnorr(message));
        channel_announcement.node1_signature = Some(node1_sk.sign(message));
        channel_announcement.node2_signature = Some(node2_sk.sign(message));

        ChannelTestContext {
            funding_tx_sk,
            node1_sk,
            node2_sk,
            funding_tx,
            channel_announcement,
        }
    }

    pub fn channel_outpoint(&self) -> &OutPoint {
        &self.channel_announcement.channel_outpoint
    }

    pub fn create_channel_update_of_node1(
        &self,
        channel_flags: ChannelUpdateChannelFlags,
        tlc_expiry_delta: u64,
        tlc_minimum_value: u128,
        tlc_fee_proportional_millionths: u128,
        timestamp: Option<u64>,
    ) -> ChannelUpdate {
        let timestamp = timestamp.unwrap_or(now_timestamp_as_millis_u64());
        let mut unsigned_channel_update = new_channel_update_unsigned(
            self.channel_announcement.channel_outpoint.clone(),
            timestamp,
            ChannelUpdateMessageFlags::UPDATE_OF_NODE1,
            channel_flags,
            tlc_expiry_delta,
            tlc_minimum_value,
            tlc_fee_proportional_millionths,
        );
        let message = unsigned_channel_update.message_to_sign();
        let signature = self.node1_sk.sign(message);
        unsigned_channel_update.signature = Some(signature);
        unsigned_channel_update
    }

    pub fn create_channel_update_of_node2(
        &self,
        channel_flags: ChannelUpdateChannelFlags,
        tlc_expiry_delta: u64,
        tlc_minimum_value: u128,
        tlc_fee_proportional_millionths: u128,
        timestamp: Option<u64>,
    ) -> ChannelUpdate {
        let timestamp = timestamp.unwrap_or(now_timestamp_as_millis_u64());
        let mut unsigned_channel_update = new_channel_update_unsigned(
            self.channel_announcement.channel_outpoint.clone(),
            timestamp,
            ChannelUpdateMessageFlags::UPDATE_OF_NODE2,
            channel_flags,
            tlc_expiry_delta,
            tlc_minimum_value,
            tlc_fee_proportional_millionths,
        );
        let message = unsigned_channel_update.message_to_sign();
        let signature = self.node2_sk.sign(message);
        unsigned_channel_update.signature = Some(signature);
        unsigned_channel_update
    }
}

pub fn create_invalid_ecdsa_signature() -> EcdsaSignature {
    let sk = Privkey::from([42u8; 32]);
    sk.sign([0u8; 32])
}
