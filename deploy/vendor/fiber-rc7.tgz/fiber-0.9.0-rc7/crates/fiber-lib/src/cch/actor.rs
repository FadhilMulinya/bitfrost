use anyhow::{anyhow, Context, Result};
use lightning_invoice::Bolt11Invoice;
use lightning_invoice::Currency as LnCurrency;
use lnd_grpc_tonic_client::{invoicesrpc, Uri};
use ractor::{
    port::OutputPortSubscriberTrait as _, Actor, ActorProcessingErr, ActorRef, OutputPort,
    RpcReplyPort,
};
use secp256k1::{PublicKey, SecretKey, SECP256K1};
use serde::Deserialize;
use std::str::FromStr;
use std::sync::Arc;
use tentacle::secio::SecioKeyPair;
use tokio_util::sync::CancellationToken;
use tokio_util::task::TaskTracker;

use crate::cch::actions::{ActionDispatcher, CchOrderAction};
use crate::cch::cch_fiber_agent::{CchFiberAgentActor, CchFiberAgentHttpBackend, CchFiberAgentRef};
use crate::cch::order::CchOrderStateMachine;
use crate::cch::scheduler::{CchOrderSchedulerActor, SchedulerArgs, SchedulerMessage};
use crate::cch::trackers::{
    CchTrackingEvent, LndConnectionInfo, LndTrackerActor, LndTrackerArgs, LndTrackerMessage,
    RedactedCchTrackingEvent,
};
use crate::cch::{CchConfig, CchError, CchOrderStore, CchStoreError};
use crate::ckb::contracts::{get_script_by_contract, Contract};
use crate::fiber::NetworkActorMessage;
use crate::invoice::{CkbInvoice, CkbInvoiceStatus, Currency, InvoiceBuilder};
use crate::now_timestamp_as_millis_u64;
use crate::store::store_impl::StoreChange;
use crate::time::Duration;
use fiber_types::{AttemptStatus, CchInvoice, CchOrder, CchOrderStatus, HashAlgorithm};
use fiber_types::{Hash256, Privkey};

pub const ACTION_RETRY_BASE_MILLIS: u64 = 1000; // 1 second initial delay
pub const ACTION_RETRY_MAX_MILLIS: u64 = 600_000; // 10 minute max delay

/// Average time per Bitcoin block in milliseconds (10 minutes = 600 seconds = 600,000 ms).
pub const BTC_BLOCK_TIME_MILLIS: u64 = 600_000;

fn calculate_retry_delay(retry_count: u32) -> Duration {
    // Exponential backoff starting from ACTION_RETRY_BASE_MILLIS, capped at ACTION_RETRY_MAX_MILLIS
    let max_shift = (ACTION_RETRY_MAX_MILLIS / ACTION_RETRY_BASE_MILLIS).ilog2();
    let delay = ACTION_RETRY_BASE_MILLIS.saturating_mul(1 << retry_count.min(max_shift));
    Duration::from_millis(delay.min(ACTION_RETRY_MAX_MILLIS))
}

#[derive(Clone, Debug, Deserialize)]
pub struct SendBTC {
    pub btc_pay_req: String,
    pub currency: Currency,
}

#[derive(Clone, Debug, Deserialize)]
pub struct ReceiveBTC {
    pub fiber_pay_req: String,
}

pub enum CchMessage {
    SendBTC(SendBTC, RpcReplyPort<Result<CchOrder, CchError>>),
    ReceiveBTC(ReceiveBTC, RpcReplyPort<Result<CchOrder, CchError>>),

    GetCchOrder(Hash256, RpcReplyPort<Result<CchOrder, CchError>>),

    TrackingEvent(CchTrackingEvent),

    /// Store change event from the Fiber node (either in-process or via WebSocket).
    StoreChangeEvent(StoreChange),

    /// Schedule a retry for an action with backoff after a transient failure.
    ActionRetry {
        payment_hash: Hash256,
        action: CchOrderAction,
        retry_count: u32,
        reason: String,
    },

    ExecuteAction {
        payment_hash: Hash256,
        action: CchOrderAction,
        retry_count: u32,
    },

    /// Test-only message to insert an order directly into the database
    #[cfg(test)]
    InsertOrder(CchOrder, RpcReplyPort<Result<(), CchError>>),
}

impl From<CchTrackingEvent> for CchMessage {
    fn from(value: CchTrackingEvent) -> Self {
        CchMessage::TrackingEvent(value)
    }
}

impl From<StoreChange> for CchMessage {
    fn from(value: StoreChange) -> Self {
        CchMessage::StoreChangeEvent(value)
    }
}

pub struct CchActor<S>(std::marker::PhantomData<S>);

impl<S> Default for CchActor<S> {
    fn default() -> Self {
        Self(std::marker::PhantomData)
    }
}

pub struct CchArgs<S> {
    pub config: CchConfig,
    pub tracker: TaskTracker,
    pub token: CancellationToken,
    pub network_actor: Option<ActorRef<NetworkActorMessage>>,
    pub node_keypair: Option<crate::fiber::KeyPair>,
    pub store: S,
    /// The CKB network currency this node is configured for.
    /// Used to validate that incoming invoices match the expected network.
    pub currency: Currency,
}

pub struct CchState<S> {
    pub(super) config: CchConfig,
    pub(super) fiber_agent_ref: CchFiberAgentRef,
    pub(super) node_keypair: Option<(PublicKey, SecretKey)>,
    pub(super) lnd_connection: LndConnectionInfo,
    pub(super) lnd_tracker: ActorRef<LndTrackerMessage>,
    pub(super) scheduler: ActorRef<SchedulerMessage>,
    pub(super) store: S,
    /// The CKB network currency this node is configured for.
    pub(super) currency: Currency,
}

#[async_trait::async_trait]
impl<S: CchOrderStore + Send + Sync + Clone + 'static> Actor for CchActor<S> {
    type Msg = CchMessage;
    type State = CchState<S>;
    type Arguments = CchArgs<S>;

    async fn pre_start(
        &self,
        myself: ActorRef<Self::Msg>,
        args: Self::Arguments,
    ) -> Result<Self::State, ActorProcessingErr> {
        // Validate generic config invariants (e.g. the outgoing fee budget percentage).
        args.config.validate().map_err(|e| anyhow!(e))?;

        // Validate that we have either an in-process network actor or a fiber RPC URL
        if args.network_actor.is_none() {
            if args.config.fiber_rpc_url.is_none() {
                return Err(anyhow!(
                    "Cch requires either in-process network actor or configured fiber RPC URL"
                )
                .into());
            }
            ensure_fiber_http_url(args.config.fiber_rpc_url.clone())?;
        }

        let lnd_rpc_url: Uri = args.config.lnd_rpc_url.clone().try_into()?;
        let cert = match args.config.resolve_lnd_cert_path() {
            Some(path) => Some(
                tokio::fs::read(&path)
                    .await
                    .with_context(|| format!("read cert file {}", path.display()))?,
            ),
            None => None,
        };
        let macaroon = match args.config.resolve_lnd_macaroon_path() {
            Some(path) => Some(
                tokio::fs::read(&path)
                    .await
                    .with_context(|| format!("read macaroon file {}", path.display()))?,
            ),
            None => None,
        };
        let lnd_connection = LndConnectionInfo::new(lnd_rpc_url, cert, macaroon);

        let node_keypair = args.node_keypair.map(|kp| {
            let private_key: Privkey = <[u8; 32]>::try_from(kp.as_ref())
                .expect("valid length for key")
                .into();
            let secio_kp = SecioKeyPair::from(kp);
            (
                PublicKey::from_slice(secio_kp.public_key().inner_ref()).expect("valid public key"),
                private_key.into(),
            )
        });

        // Create LND tracker port and subscribe
        let lnd_port = Arc::new(OutputPort::default());
        let lnd_tracker = LndTrackerActor::start(
            LndTrackerArgs {
                port: lnd_port.clone(),
                lnd_connection: lnd_connection.clone(),
                tracker: args.tracker.clone(),
                token: args.token.clone(),
            },
            myself.get_cell(),
        )
        .await?;
        myself.subscribe_to_port(&lnd_port);

        // Start scheduler actor
        let scheduler = CchOrderSchedulerActor::start(
            SchedulerArgs {
                store: args.store.clone(),
                lnd_tracker: lnd_tracker.clone(),
            },
            myself.get_cell(),
        )
        .await?;

        // Set up store change subscription
        if args.network_actor.is_none() {
            // Separate service mode: subscribe to Fiber node's store changes via WebSocket
            let ws_url = ensure_fiber_ws_url(args.config.fiber_rpc_url.clone())?;
            let myself_clone = myself.clone();
            let token = args.token.clone();
            args.tracker.spawn(async move {
                subscribe_store_changes_ws(ws_url, myself_clone, token).await;
            });
        }

        let fiber_agent_ref = if let Some(network_actor) = args.network_actor {
            CchFiberAgentRef::InProcess(network_actor)
        } else {
            let url = args
                .config
                .fiber_rpc_url
                .as_deref()
                .expect("validated in pre_start");
            let backend = CchFiberAgentHttpBackend::try_new(url)?;
            let (rpc_actor, _handle) =
                ractor::Actor::spawn_linked(None, CchFiberAgentActor, backend, myself.get_cell())
                    .await?;
            CchFiberAgentRef::Rpc(rpc_actor)
        };

        let state = CchState {
            config: args.config,
            fiber_agent_ref,
            store: args.store,
            node_keypair,
            lnd_connection,
            lnd_tracker,
            scheduler,
            currency: args.currency,
        };

        Ok(state)
    }

    async fn post_start(
        &self,
        myself: ActorRef<Self::Msg>,
        state: &mut Self::State,
    ) -> Result<(), ActorProcessingErr> {
        let current_time = now_timestamp_as_millis_u64() / 1000;

        // Load all orders from the database
        for mut order in state
            .store
            .get_cch_order_keys_iter()
            .into_iter()
            .filter_map(|payment_hash| state.store.get_cch_order(&payment_hash).ok())
        {
            // Only process active (non-final) orders
            if order.is_final() {
                state.schedule_job_for_final_order(&order);
                continue;
            }

            // Check if order is expired and mark as Failed if so
            if order.update_if_expired(current_time) {
                let payment_hash = order.payment_hash;
                state.store.update_cch_order(order.clone());
                state.schedule_job_for_final_order(&order);
                tracing::info!("Marked expired order {:x} as Failed", payment_hash);
                continue;
            }

            // Schedule expiry job for non-final orders
            state.schedule_job_for_non_final_order(&order);

            // Resume tracking for non-expired active orders
            let actions = ActionDispatcher::on_starting(&order);
            if let Err(err) = append_actions(myself.clone(), order.payment_hash, actions) {
                tracing::error!(
                    "Failed to schedule resume actions for order {:x}: {}",
                    order.payment_hash,
                    err
                );
            } else {
                tracing::debug!("Resumed tracking for active order {:x}", order.payment_hash);
            }
        }

        Ok(())
    }

    async fn handle(
        &self,
        myself: ActorRef<Self::Msg>,
        message: Self::Msg,
        state: &mut Self::State,
    ) -> Result<(), ActorProcessingErr> {
        match message {
            CchMessage::SendBTC(send_btc, port) => {
                let result = state.send_btc(send_btc).await;
                if let Ok(order) = &result {
                    // Schedule jobs for new order
                    state.schedule_job_for_non_final_order(order);
                    let actions = ActionDispatcher::on_starting(order);
                    append_actions(myself, order.payment_hash, actions)?;
                }
                if !port.is_closed() {
                    // ignore error
                    let _ = port.send(result);
                }
                Ok(())
            }
            CchMessage::ReceiveBTC(receive_btc, port) => {
                let result = state.receive_btc(receive_btc).await;
                if let Ok(order) = &result {
                    // Schedule jobs for new order
                    state.schedule_job_for_non_final_order(order);
                    let actions = ActionDispatcher::on_starting(order);
                    append_actions(myself, order.payment_hash, actions)?;
                }
                if !port.is_closed() {
                    // ignore error
                    let _ = port.send(result);
                }
                Ok(())
            }
            CchMessage::GetCchOrder(payment_hash, port) => {
                let result = state.store.get_cch_order(&payment_hash).map_err(Into::into);
                if !port.is_closed() {
                    // ignore error
                    let _ = port.send(result);
                }
                Ok(())
            }
            CchMessage::TrackingEvent(event) => {
                tracing::debug!("tracking event {:?}", RedactedCchTrackingEvent(&event));
                let payment_hash = *event.payment_hash();
                match state.handle_tracking_event(event).await {
                    Ok(actions) => {
                        append_actions(myself, payment_hash, actions)?;
                    }
                    Err(err) => {
                        // Ignore errors because events come from external systems
                        tracing::error!(
                            "handle_tracking_event for payment hash {:x} failed: {}",
                            payment_hash,
                            err
                        );
                    }
                }
                Ok(())
            }
            CchMessage::StoreChangeEvent(change) => {
                let summary = redacted_store_change_summary(&change);
                tracing::debug!(
                    "store change event kind={} payment_hash={:x} has_payment_preimage={}",
                    summary.kind,
                    summary.payment_hash,
                    summary.has_payment_preimage
                );
                let events = state.map_store_change_to_events(&change);
                for event in events {
                    let payment_hash = *event.payment_hash();
                    match state.handle_tracking_event(event).await {
                        Ok(actions) => {
                            append_actions(myself.clone(), payment_hash, actions)?;
                        }
                        Err(err) => {
                            tracing::error!(
                                "handle_tracking_event for payment hash {:x} failed: {}",
                                payment_hash,
                                err
                            );
                        }
                    }
                }
                Ok(())
            }
            CchMessage::ActionRetry {
                payment_hash,
                action,
                retry_count,
                reason,
            } => {
                if state.get_active_order_or_none(&payment_hash)?.is_none() {
                    return Ok(());
                }
                schedule_action_retry(&myself, payment_hash, action, retry_count, &reason);
                Ok(())
            }
            CchMessage::ExecuteAction {
                payment_hash,
                action,
                retry_count,
            } => {
                let order = match state.get_active_order_or_none(&payment_hash)? {
                    None => return Ok(()),
                    Some(order) => order,
                };
                if let Err(err) =
                    ActionDispatcher::execute(state, &myself, &order, action, retry_count).await
                {
                    schedule_action_retry(
                        &myself,
                        payment_hash,
                        action,
                        retry_count,
                        &err.to_string(),
                    );
                }
                Ok(())
            }
            #[cfg(test)]
            CchMessage::InsertOrder(order, port) => {
                let result = state.store.insert_cch_order(order).map_err(Into::into);
                if !port.is_closed() {
                    let _ = port.send(result);
                }
                Ok(())
            }
        }
    }
}

/// Maps a CKB network currency to the expected Lightning Network invoice currency.
///
/// - Fibb (CKB mainnet) → Bitcoin mainnet
/// - Fibt (CKB testnet) → Bitcoin testnet
/// - Fibd (CKB devnet) → Bitcoin regtest
fn expected_ln_currency(currency: Currency) -> LnCurrency {
    match currency {
        Currency::Fibb => LnCurrency::Bitcoin,
        Currency::Fibt => LnCurrency::BitcoinTestnet,
        Currency::Fibd => LnCurrency::Regtest,
    }
}

impl<S: CchOrderStore> CchState<S> {
    /// Get a CCH order by payment hash, returning None if not found.
    /// This handles the common pattern of checking for NotFound vs other errors.
    fn get_order_or_none(&self, payment_hash: &Hash256) -> Result<Option<CchOrder>, CchError> {
        match self.store.get_cch_order(payment_hash) {
            Err(CchStoreError::NotFound(_)) => Ok(None),
            Err(err) => Err(err.into()),
            Ok(order) => Ok(Some(order)),
        }
    }

    /// Get a CCH order by payment hash, returning None if not found or the order status is final.
    fn get_active_order_or_none(
        &self,
        payment_hash: &Hash256,
    ) -> Result<Option<CchOrder>, CchError> {
        Ok(self
            .get_order_or_none(payment_hash)?
            .filter(|order| !order.is_final()))
    }

    fn schedule_job_for_non_final_order(&self, order: &CchOrder) {
        if let Err(err) = self
            .scheduler
            .send_message(SchedulerMessage::ScheduleExpiry {
                payment_hash: order.payment_hash,
                created_at: order.created_at,
                expiry_delta_seconds: order.expiry_delta_seconds,
            })
        {
            tracing::error!(
                "Failed to schedule expiry job for order {:x}: {}",
                order.payment_hash,
                err
            );
        }
    }

    fn schedule_job_for_final_order(&self, order: &CchOrder) {
        let payment_hash = order.payment_hash;
        if let Err(err) = self
            .scheduler
            .send_message(SchedulerMessage::SchedulePrune {
                payment_hash,
                created_at: order.created_at,
                expiry_delta_seconds: order.expiry_delta_seconds,
            })
        {
            tracing::error!(
                "Failed to schedule prune job for final order {:x}: {}",
                payment_hash,
                err
            );
        }
    }

    fn schedule_job_on_entering(&self, order: &CchOrder) {
        if order.is_final() {
            self.schedule_job_for_final_order(order);
        } else {
            self.schedule_job_for_non_final_order(order);
        }
    }

    /// Resolve the full wrapped BTC type script.
    ///
    /// Uses the explicit `wrapped_btc_type_script` config option when set.
    /// Falls back to building the script from the contracts context using
    /// `wrapped_btc_type_script_args` (safe in non-standalone mode where the
    /// contracts context is always initialized; standalone mode enforces the
    /// config option at startup).
    fn resolve_wrapped_btc_type_script(&self) -> Result<ckb_jsonrpc_types::Script, CchError> {
        if let Some(ref json_str) = self.config.wrapped_btc_type_script {
            return serde_json::from_str(json_str).map_err(|e| {
                CchError::ConfigError(format!(
                    "failed to parse wrapped_btc_type_script JSON: {}",
                    e
                ))
            });
        }

        let args = hex::decode(
            self.config
                .wrapped_btc_type_script_args
                .trim_start_matches("0x"),
        )
        .map_err(|_| {
            CchError::HexDecodingError(self.config.wrapped_btc_type_script_args.clone())
        })?;

        Ok(get_script_by_contract(Contract::SimpleUDT, &args).into())
    }

    async fn send_btc(&self, send_btc: SendBTC) -> Result<CchOrder, CchError> {
        let order_created_at = now_timestamp_as_millis_u64() / 1000;

        // Validate that the currency matches the configured CKB network (#981)
        if send_btc.currency != self.currency {
            return Err(CchError::CKBInvoiceNetworkMismatch {
                expected: self.currency,
                actual: send_btc.currency,
            });
        }

        let invoice = Bolt11Invoice::from_str(&send_btc.btc_pay_req)?;
        tracing::debug!(
            "BTC invoice parsed payment_hash={:x} currency={:?} has_amount={}",
            Hash256::from(*invoice.payment_hash()),
            invoice.currency(),
            invoice.amount_milli_satoshis().is_some()
        );

        // Validate that the BTC invoice network matches the expected BTC network (#978)
        let expected_ln_currency = expected_ln_currency(self.currency);
        let actual_ln_currency = invoice.currency();
        if actual_ln_currency != expected_ln_currency {
            return Err(CchError::BTCInvoiceNetworkMismatch {
                expected: format!("{:?}", expected_ln_currency),
                actual: format!("{:?}", actual_ln_currency),
            });
        }

        let payment_hash = Hash256::from(*invoice.payment_hash());

        let invoice_created_at = invoice.duration_since_epoch().as_secs();
        if invoice_created_at > order_created_at {
            return Err(CchError::BTCInvoiceCreationTimeInFuture {
                invoice_created_at,
                order_created_at,
            });
        }

        // Validate that outgoing BTC invoice's final CLTV is less than half of incoming CKB invoice's final TLC expiry.
        // This ensures the CCH operator has sufficient time to settle the incoming side before the outgoing side expires.
        // BTC uses blocks (~10 min each), CKB uses seconds.
        let btc_final_cltv_seconds = invoice
            .min_final_cltv_expiry_delta()
            .checked_mul(600)
            .ok_or(CchError::BTCInvoiceFinalTlcExpiryDeltaTooLarge)?;
        let ckb_final_tlc_seconds = self.config.ckb_final_tlc_expiry_delta_seconds;
        if btc_final_cltv_seconds >= ckb_final_tlc_seconds / 2 {
            return Err(CchError::BTCInvoiceFinalTlcExpiryDeltaTooLarge);
        }

        let outgoing_invoice_expiry_delta_seconds = invoice
            .expires_at()
            .and_then(|expired_at| expired_at.as_secs().checked_sub(order_created_at))
            .ok_or(CchError::BTCInvoiceExpired)?;
        if outgoing_invoice_expiry_delta_seconds
            < self.config.min_outgoing_invoice_expiry_delta_seconds
        {
            return Err(CchError::OutgoingInvoiceExpiryTooShort);
        }

        let amount_msat = invoice
            .amount_milli_satoshis()
            .ok_or(CchError::BTCInvoiceMissingAmount)? as u128;

        let fee_sats = amount_msat
            .checked_mul(self.config.fee_rate_per_million_sats as u128)
            .and_then(|v| v.checked_div(1_000_000_000u128))
            .and_then(|v| v.checked_add(self.config.base_fee_sats as u128))
            .ok_or(CchError::SendBTCOrderAmountTooLarge)?;

        let wrapped_btc_type_script = self.resolve_wrapped_btc_type_script()?;
        let invoice_amount_sats = amount_msat
            .div_ceil(1_000u128)
            .checked_add(fee_sats)
            .ok_or(CchError::SendBTCOrderAmountTooLarge)?;

        let invoice_builder = InvoiceBuilder::new(send_btc.currency)
            .amount(Some(invoice_amount_sats))
            .payment_hash(payment_hash)
            .hash_algorithm(HashAlgorithm::Sha256)
            .expiry_time(Duration::from_secs(outgoing_invoice_expiry_delta_seconds))
            .final_expiry_delta(
                self.config
                    .ckb_final_tlc_expiry_delta_seconds
                    .checked_mul(1000)
                    .ok_or_else(|| {
                        CchError::ConfigError(format!(
                            "ckb_final_tlc_expiry_delta_seconds ({}) is too large and causes overflow when converting to milliseconds",
                            self.config.ckb_final_tlc_expiry_delta_seconds
                        ))
                    })?,
            )
            .udt_type_script(wrapped_btc_type_script.clone().into());

        let invoice = if let Some((public_key, secret_key)) = &self.node_keypair {
            invoice_builder
                .payee_pub_key(*public_key)
                .build_with_sign(|hash| SECP256K1.sign_ecdsa_recoverable(hash, secret_key))
        } else {
            invoice_builder.build()
        }?;

        let invoice = self.fiber_agent_ref.call_add_invoice(invoice).await?;

        let order = CchOrder {
            amount_sats: invoice_amount_sats,
            created_at: order_created_at,
            expiry_delta_seconds: self.config.order_expiry_delta_seconds,
            failure_reason: None,
            incoming_invoice: CchInvoice::Fiber(invoice),
            outgoing_pay_req: send_btc.btc_pay_req,
            payment_preimage: None,
            status: CchOrderStatus::Pending,
            fee_sats,
            payment_hash,
            wrapped_btc_type_script,
        };

        self.store.insert_cch_order(order.clone())?;
        Ok(order)
    }

    async fn receive_btc(&self, receive_btc: ReceiveBTC) -> Result<CchOrder, CchError> {
        // `from_str` requires the invoice to carry a valid signature, so parsing
        // here also guarantees the Fiber invoice is signed.
        let invoice = CkbInvoice::from_str(&receive_btc.fiber_pay_req)?;

        // Validate that the CKB invoice currency matches the configured network (#982)
        if invoice.currency != self.currency {
            return Err(CchError::CKBInvoiceNetworkMismatch {
                expected: self.currency,
                actual: invoice.currency,
            });
        }

        let payment_hash = *invoice.payment_hash();
        let amount_sats = invoice.amount().ok_or(CchError::CKBInvoiceMissingAmount)?;

        // Validate amount and fee early so we reject overflow/too-large before other checks.
        let fee_sats = amount_sats
            .checked_mul(self.config.fee_rate_per_million_sats as u128)
            .and_then(|v| v.checked_div(1_000_000u128))
            .and_then(|v| v.checked_add(self.config.base_fee_sats as u128))
            .ok_or(CchError::ReceiveBTCOrderAmountTooLarge)?;
        let total_msat = i64::try_from(
            amount_sats
                .checked_add(fee_sats)
                .and_then(|s| s.checked_mul(1_000u128))
                .unwrap_or(u128::MAX),
        )
        .map_err(|_| CchError::ReceiveBTCOrderAmountTooLarge)?;

        // Validate that outgoing CKB invoice's final TLC is less than half of incoming BTC invoice's final CLTV expiry.
        // This ensures the CCH operator has sufficient time to settle the incoming side before the outgoing side expires.
        // CKB uses milliseconds, BTC uses blocks (~10 min each).
        let ckb_final_tlc_millis = invoice
            .final_tlc_minimum_expiry_delta()
            .copied()
            .unwrap_or(0);
        let btc_final_cltv_millis = self
            .config
            .btc_final_tlc_expiry_delta_blocks
            .checked_mul(BTC_BLOCK_TIME_MILLIS)
            .ok_or_else(|| {
                CchError::ConfigError(format!(
                    "btc_final_tlc_expiry_delta_blocks ({}) is too large and causes overflow when converting to milliseconds",
                    self.config.btc_final_tlc_expiry_delta_blocks
                ))
            })?;
        if ckb_final_tlc_millis >= btc_final_cltv_millis / 2 {
            return Err(CchError::CKBInvoiceFinalTlcExpiryDeltaTooLarge);
        }

        let order_created_at_ms = now_timestamp_as_millis_u64();
        let order_created_at = order_created_at_ms / 1000;
        if invoice.data.timestamp > u128::from(order_created_at_ms) {
            return Err(CchError::CKBInvoiceCreationTimeInFuture {
                invoice_created_at_ms: invoice.data.timestamp,
                order_created_at_ms: u128::from(order_created_at_ms),
            });
        }

        // Convert timestamp + expiry_time to the expiry time relative to `duration_since`.
        let outgoing_invoice_expiry_delta_seconds = match invoice.expiry_time() {
            Some(expiry) => invoice
                .data
                .timestamp
                .checked_add(expiry.as_millis())
                .and_then(|expiry_at| {
                    u64::try_from(expiry_at / 1000)
                        .unwrap_or(u64::MAX)
                        .checked_sub(order_created_at)
                })
                .ok_or(CchError::OutgoingInvoiceExpiryTooShort)?,
            // CKB invoice has no default expiry, use minimal * 2 to create the invoice
            None => self
                .config
                .min_outgoing_invoice_expiry_delta_seconds
                .checked_mul(2)
                .ok_or(CchError::OutgoingInvoiceExpiryTooShort)?,
        };
        if outgoing_invoice_expiry_delta_seconds
            < self.config.min_outgoing_invoice_expiry_delta_seconds
        {
            return Err(CchError::OutgoingInvoiceExpiryTooShort);
        }

        // Verify wrapped_btc_type_script matches invoice UDT type script
        let wrapped_btc_type_script = self.resolve_wrapped_btc_type_script()?;

        // Verify invoice UDT type script matches configured wrapped_btc_type_script
        if let Some(invoice_udt_script) = invoice.udt_type_script() {
            let invoice_script: ckb_jsonrpc_types::Script = invoice_udt_script.clone().into();
            if invoice_script.code_hash != wrapped_btc_type_script.code_hash
                || invoice_script.hash_type != wrapped_btc_type_script.hash_type
                || invoice_script.args != wrapped_btc_type_script.args
            {
                return Err(CchError::WrappedBTCTypescriptMismatch);
            }
        } else {
            return Err(CchError::WrappedBTCTypescriptMismatch);
        }

        // Validate hash algorithm - must be SHA256 for LND compatibility
        let hash_algorithm = invoice.hash_algorithm().copied().unwrap_or_default();
        if hash_algorithm != HashAlgorithm::Sha256 {
            return Err(CchError::CKBInvoiceIncompatibleHashAlgorithm);
        }

        let mut client = self.lnd_connection.create_invoices_client().await?;
        let req = invoicesrpc::AddHoldInvoiceRequest {
            hash: payment_hash.as_ref().to_vec(),
            value_msat: total_msat,
            expiry: outgoing_invoice_expiry_delta_seconds as i64,
            cltv_expiry: self.config.btc_final_tlc_expiry_delta_blocks,
            ..Default::default()
        };
        let add_invoice_resp = client
            .add_hold_invoice(req.clone())
            .await
            .map_err(|err| CchError::LndRpcError(format!("{}, request: {:?}", err, req)))?
            .into_inner();
        let incoming_invoice = Bolt11Invoice::from_str(&add_invoice_resp.payment_request)?;

        let order = CchOrder {
            created_at: order_created_at,
            expiry_delta_seconds: self.config.order_expiry_delta_seconds,
            failure_reason: None,
            incoming_invoice: CchInvoice::Lightning(incoming_invoice),
            outgoing_pay_req: receive_btc.fiber_pay_req,
            payment_preimage: None,
            status: CchOrderStatus::Pending,
            amount_sats,
            fee_sats,
            payment_hash,
            wrapped_btc_type_script,
        };

        self.store.insert_cch_order(order.clone())?;
        Ok(order)
    }

    async fn handle_tracking_event(&self, event: CchTrackingEvent) -> Result<Vec<CchOrderAction>> {
        let mut order = match self.get_active_order_or_none(event.payment_hash())? {
            None => return Ok(vec![]),
            Some(order) => order,
        };

        if order.status == CchOrderStatus::Pending
            && matches!(
                &event,
                CchTrackingEvent::InvoiceChanged {
                    status: CkbInvoiceStatus::Received,
                    ..
                }
            )
        {
            let current_time = now_timestamp_as_millis_u64() / 1000;
            if order.update_if_expired_with_reason(current_time, "Order expired") {
                self.store.update_cch_order(order.clone());
                self.schedule_job_on_entering(&order);
                tracing::info!(
                    "Rejected incoming invoice event for expired pending order {:x}",
                    order.payment_hash
                );
                return Ok(vec![]);
            }
        }

        if CchOrderStateMachine::apply(&mut order, event.into())?.is_some() {
            self.store.update_cch_order(order.clone());
            self.schedule_job_on_entering(&order);
            Ok(ActionDispatcher::on_entering(&order))
        } else {
            Ok(vec![])
        }
    }

    /// Map a StoreChange into CchTrackingEvent(s).
    /// This replaces the old CchFiberStoreWatcher: the mapping logic now lives in the actor.
    fn map_store_change_to_events(&self, change: &StoreChange) -> Vec<CchTrackingEvent> {
        match change {
            StoreChange::PutCkbInvoiceStatus {
                payment_hash,
                invoice_status,
            } => vec![CchTrackingEvent::InvoiceChanged {
                payment_hash: *payment_hash,
                status: *invoice_status,
                failure_reason: None,
            }],
            StoreChange::PutPaymentSession {
                payment_hash,
                payment_session,
            } => {
                use fiber_types::payment::PaymentStatus;
                let status = payment_session.status;
                // For successful payments, we need the preimage. If it's not in the same
                // store change batch, the PutPreimage event will follow.
                if status == PaymentStatus::Success {
                    // Defer to PutPreimage
                    vec![]
                } else {
                    vec![CchTrackingEvent::PaymentChanged {
                        payment_hash: *payment_hash,
                        payment_preimage: None,
                        status,
                        failure_reason: None,
                    }]
                }
            }
            StoreChange::PutAttempt {
                payment_hash,
                attempt_status: AttemptStatus::Inflight,
            } => {
                use fiber_types::payment::PaymentStatus;
                vec![CchTrackingEvent::PaymentChanged {
                    payment_hash: *payment_hash,
                    payment_preimage: None,
                    status: PaymentStatus::Inflight,
                    failure_reason: None,
                }]
            }
            StoreChange::PutAttempt { .. } => vec![],
            StoreChange::PutPreimage {
                payment_hash,
                payment_preimage,
            } => {
                use fiber_types::payment::PaymentStatus;
                vec![CchTrackingEvent::PaymentChanged {
                    payment_hash: *payment_hash,
                    payment_preimage: Some(*payment_preimage),
                    status: PaymentStatus::Success,
                    failure_reason: None,
                }]
            }
        }
    }
}

fn append_actions(
    myself: ActorRef<CchMessage>,
    payment_hash: Hash256,
    actions: Vec<CchOrderAction>,
) -> Result<(), ActorProcessingErr> {
    for action in actions {
        myself.send_message(CchMessage::ExecuteAction {
            payment_hash,
            action,
            retry_count: 0,
        })?;
    }
    Ok(())
}

fn schedule_action_retry(
    myself: &ActorRef<CchMessage>,
    payment_hash: Hash256,
    action: CchOrderAction,
    retry_count: u32,
    reason: &str,
) {
    let delay = calculate_retry_delay(retry_count);
    tracing::error!(
        "action {:?} for payment hash {:x} failed (retry {}): {}. Retrying in {:?}",
        action,
        payment_hash,
        retry_count,
        reason,
        delay
    );
    // Retry the action later with exponential backoff. The action executor will
    // cease retrying only when it handles the error internally and returns OK.
    myself.send_after(delay, move || CchMessage::ExecuteAction {
        payment_hash,
        action,
        retry_count: retry_count.saturating_add(1),
    });
}

fn ensure_fiber_http_url(url_opt: Option<String>) -> Result<String> {
    if let Some(url) = url_opt {
        if url.starts_with("http://") || url.starts_with("https://") {
            return Ok(url);
        }
    }
    Err(anyhow!("fiber_rpc_url must start with http:// or https://"))
}

fn ensure_fiber_ws_url(url_opt: Option<String>) -> Result<String> {
    let mut url = ensure_fiber_http_url(url_opt)?;
    // replace http with ws
    url.replace_range(..4, "ws");
    Ok(url)
}

/// Subscribe to store changes from a Fiber node via WebSocket RPC.
/// Reconnects automatically on failure until the cancellation token is triggered.
async fn subscribe_store_changes_ws(
    ws_url: String,
    actor: ActorRef<CchMessage>,
    token: CancellationToken,
) {
    use jsonrpsee::ws_client::WsClientBuilder;

    loop {
        if token.is_cancelled() {
            return;
        }

        tracing::info!(
            "Connecting to Fiber node WebSocket for store changes at {}",
            ws_url
        );

        let client = match WsClientBuilder::default().build(&ws_url).await {
            Ok(client) => client,
            Err(err) => {
                tracing::error!(
                    "Failed to connect to Fiber WebSocket at {}: {}. Retrying in 5s.",
                    ws_url,
                    err
                );
                tokio::select! {
                    _ = tokio::time::sleep(std::time::Duration::from_secs(5)) => continue,
                    _ = token.cancelled() => return,
                }
            }
        };

        use jsonrpsee::core::client::SubscriptionClientT as _;
        let mut subscription = match client
            .subscribe::<StoreChange, _>(
                "subscribe_store_changes",
                jsonrpsee::rpc_params![],
                "unsubscribe_store_changes",
            )
            .await
        {
            Ok(sub) => sub,
            Err(err) => {
                tracing::error!(
                    "Failed to subscribe to store changes: {}. Retrying in 5s.",
                    err
                );
                tokio::select! {
                    _ = tokio::time::sleep(std::time::Duration::from_secs(5)) => continue,
                    _ = token.cancelled() => return,
                }
            }
        };

        tracing::info!("Successfully subscribed to Fiber node store changes");

        loop {
            tokio::select! {
                item = subscription.next() => {
                    match item {
                        Some(Ok(change)) => {
                            let summary = redacted_store_change_summary(&change);
                            tracing::debug!(
                                "received store change via websocket kind={} payment_hash={:x} has_payment_preimage={}",
                                summary.kind,
                                summary.payment_hash,
                                summary.has_payment_preimage
                            );
                            if let Err(err) = actor.send_message(CchMessage::StoreChangeEvent(change)) {
                                tracing::error!("Failed to forward store change to CCH actor: {}", err);
                                return;
                            }
                        }
                        Some(Err(err)) => {
                            tracing::error!("WebSocket subscription error: {}. Reconnecting...", err);
                            break;
                        }
                        None => {
                            tracing::warn!("WebSocket subscription ended. Reconnecting...");
                            break;
                        }
                    }
                }
                _ = token.cancelled() => {
                    tracing::info!("Cancellation received, stopping WebSocket subscription");
                    return;
                }
            }
        }
    }
}

#[derive(Debug)]
pub(crate) struct RedactedStoreChangeSummary {
    pub kind: &'static str,
    pub payment_hash: Hash256,
    pub has_payment_preimage: bool,
}

pub(crate) fn redacted_store_change_summary(change: &StoreChange) -> RedactedStoreChangeSummary {
    match change {
        StoreChange::PutCkbInvoiceStatus { payment_hash, .. } => RedactedStoreChangeSummary {
            kind: "PutCkbInvoiceStatus",
            payment_hash: *payment_hash,
            has_payment_preimage: false,
        },
        StoreChange::PutPaymentSession { payment_hash, .. } => RedactedStoreChangeSummary {
            kind: "PutPaymentSession",
            payment_hash: *payment_hash,
            has_payment_preimage: false,
        },
        StoreChange::PutAttempt { payment_hash, .. } => RedactedStoreChangeSummary {
            kind: "PutAttempt",
            payment_hash: *payment_hash,
            has_payment_preimage: false,
        },
        StoreChange::PutPreimage { payment_hash, .. } => RedactedStoreChangeSummary {
            kind: "PutPreimage",
            payment_hash: *payment_hash,
            has_payment_preimage: true,
        },
    }
}
